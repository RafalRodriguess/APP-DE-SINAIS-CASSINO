<div class="card-body">
    <h5 class="card-title">How To Use</h5>
    <p>You can get the value of this setting anywhere on your site by calling <code>setting('key')</code></p>
</div>