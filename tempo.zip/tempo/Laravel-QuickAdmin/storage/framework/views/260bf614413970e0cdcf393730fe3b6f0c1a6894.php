[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /Users/user/Desktop/php/QuickAdmin/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>