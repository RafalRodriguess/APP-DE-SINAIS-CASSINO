<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH /Users/user/Desktop/php/QuickAdmin/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/footer.blade.php ENDPATH**/ ?>