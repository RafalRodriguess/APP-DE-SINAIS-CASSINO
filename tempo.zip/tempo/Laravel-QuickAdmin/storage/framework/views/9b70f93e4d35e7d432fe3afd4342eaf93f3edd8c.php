<div class="list-group">
    <a href="<?php echo e(route('app.settings.general')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('app.settings.general') ? 'active' : ''); ?>">General</a>
    <a href="<?php echo e(route('app.settings.appearence')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('app.settings.appearence') ? 'active' : ''); ?>">Appearence</a>
    <a href="<?php echo e(route('app.settings.mail')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('app.settings.mail') ? 'active' : ''); ?>">Mail</a>
    <a href="<?php echo e(route('app.settings.socialite')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('app.settings.socialite') ? 'active' : ''); ?>">Socialite</a>
</div><?php /**PATH /Users/user/Desktop/php/QuickAdmin/resources/views/backend/settings/list.blade.php ENDPATH**/ ?>